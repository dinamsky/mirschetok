<?php

class waVerificationChannelParamsModel extends waParamsModel
{
    protected $table = 'wa_verification_channel_params';
    protected $external_id = 'channel_id';
    protected $serializing = true;
}

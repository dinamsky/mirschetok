<?php

return array(
    'code' => 'NOK',
    'sign' => 'kr',
	'iso4217' => '578',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Norwegian krone',
    'name' => array(
        array('krone', 'kroner'),
    ),
    'frac_name' => array(
		'ore',
    )
);
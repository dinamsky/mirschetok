<?php

return array(
    'code' => 'MGA',
    'sign' => 'Ar',
	'iso4217' => '969',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Malagasy ariary',
    'name' => array(
        'ariary',
    ),
    'frac_name' => array(
        'iraimbilanja'
    )
);

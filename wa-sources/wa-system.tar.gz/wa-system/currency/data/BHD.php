<?php

return array(
    'code' => 'BHD',
    'sign' => '.د.ب',
	'iso4217' => '48',
    'sign_position' => 0,
    'sign_delim' => ' ',
    'title' => 'Bahraini dinar',
    'name' => array(
        array('dinar', 'dinars'),
        'BD',
    ),
    'frac_name' => array(
        'fils',
    )
);
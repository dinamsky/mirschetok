<?php

/**
 * @deprecated
 * TODO: delete in next iteration
 * Dont' touch this class, don't use
 * Class exists for temporary backward compatibility
 */
class waWebasystIDAuth extends waWebasystIDWAAuth
{
}

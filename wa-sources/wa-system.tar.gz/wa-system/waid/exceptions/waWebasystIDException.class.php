<?php

class waWebasystIDException extends waException {}

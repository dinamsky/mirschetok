<?php

/**
 * Class waWebasystIDAuthException
 *
 * Exception from waWebasustIDAuth adapter
 */
class waWebasystIDAuthException extends waWebasystIDException {}

<?php

class waWebasystIDAccessDeniedAuthException extends waWebasystIDException {}

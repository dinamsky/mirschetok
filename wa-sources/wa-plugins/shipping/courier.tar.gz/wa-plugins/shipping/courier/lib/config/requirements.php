<?php
return array(
    'app.installer' => array(
        'strict'  => true,
        'version' => 'latest', // 1.10.0
    ),
);

<?php
return 40;

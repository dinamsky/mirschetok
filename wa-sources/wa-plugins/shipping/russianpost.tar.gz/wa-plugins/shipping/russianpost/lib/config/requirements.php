<?php

return array(

    'php.gd'        => array(
        'description' => 'Printfom display',
        'strict'      => false,
        'value'       => 1,
    ),
    'app.installer' => array(
        'strict'  => true,
        'version' => 'latest', // 1.10.0
    ),
);

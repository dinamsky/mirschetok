<?php
return array(
    'name'             => /*_wp*/('Worldwide'),
    'description'      => /*_wp*/('Reliable international delivery tailored to local conditions.'),
    'icon'             => 'img/worldwide16.png',
    'logo'             => 'img/worldwide.png',
    'version'          => '1.1.2',
    'vendor'           => 'webasyst',
    'services_by_type' => true,
);

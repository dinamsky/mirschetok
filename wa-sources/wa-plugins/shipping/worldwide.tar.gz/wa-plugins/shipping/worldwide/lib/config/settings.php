<?php
return array(
    'weight_dimension' => array(
        'value' => 'kg',
    ),
    'currency'         => array(
        'value' => 'USD',
    ),
    'delivery_table'   => array(
        'value' => array(),
    ),
    'weights'          => array(
        'value' => 'all',
    ),
    'service_name'     => array(
        'value' => '',
    ),
);

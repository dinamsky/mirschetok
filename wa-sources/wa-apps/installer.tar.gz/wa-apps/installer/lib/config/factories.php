<?php

return array(
    'front_controller' => 'installerFrontController',
    'view'             => array('waSmarty3View'),
);

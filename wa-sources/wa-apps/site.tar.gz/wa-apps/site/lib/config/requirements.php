<?php
return array(
    'php' => array(
        'strict'  => true,
        'version' => '>=5.6.25',
    ),
    'app.installer'=>array(
        'version' => 'latest', // >=1.14.7
        'strict'  => true,
    ),
);
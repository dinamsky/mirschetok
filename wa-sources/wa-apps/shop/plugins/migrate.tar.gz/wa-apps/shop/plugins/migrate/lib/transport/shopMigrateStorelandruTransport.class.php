<?php

/**
 * Class shopMigrateStorelandruTransport
 * @title StoreLand ru
 * @description Перенос данных из магазинов на платформе StoreLand.ru посредством YML файла
 * @group YML
 */
class shopMigrateStorelandruTransport extends shopMigrateYmlTransport
{

}

<?php
/**
 * Sidebar for products list section.
 */
class shopProdListSidebarAction extends waViewAction
{
    public function execute()
    {
        die('not used! kill me and also my template'); // !!! TODO
    }
}
